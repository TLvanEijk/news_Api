export const environment = {
  production: false,
  apikey: '0b0mpMbyy0HBRAsdwIActGqpeFi9hCDK',
  apiUrl: 'https://api.nytimes.com/svc'
};