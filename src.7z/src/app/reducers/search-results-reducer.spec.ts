import { SearchResultsReducer } from './search-results-reducer';

describe('SearchResultsReducer', () => {
  it('should create an instance', () => {
    expect(new SearchResultsReducer()).toBeTruthy();
  });
});
