import { MenuReducer } from './menu-reducer';

describe('MenuReducer', () => {
  it('should create an instance', () => {
    expect(new MenuReducer()).toBeTruthy();
  });
});
