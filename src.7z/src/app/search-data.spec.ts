
import { SearchData } from './search-data';

describe('SearchData', () => {
  it('should create an instance', () => {
    expect(new SearchData()).toBeTruthy();
  });
});